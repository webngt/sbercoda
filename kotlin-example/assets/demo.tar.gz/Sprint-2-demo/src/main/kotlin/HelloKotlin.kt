
//Вывести Hello, Kotlin!
fun printHello() {
    println("Hello, Kotlin!")
}